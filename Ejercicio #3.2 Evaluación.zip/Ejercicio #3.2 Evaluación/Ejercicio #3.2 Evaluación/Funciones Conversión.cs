﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio__3._2_Evaluación
{
    internal class ConversionTemperaturas
    {
        // Funcion para convertir de Celsius a Fahrenheit
        public static double ConvertirAFahrenheit(double celsius)
        {
            return (celsius * 9 / 5) + 32;
        }

        // Funcion para convertir de Celsius a Kelvin
        public static double ConvertirAKelvin(double celsius)
        {
            return celsius + 273.15;
        }

        // Funcion para imprimir las temperaturas convertidas
        public static void ImprimirListaTemperaturas(List<double> temperaturas, string tipo)
        {
            Console.WriteLine($"Temperaturas en {tipo}:");
            foreach (var temp in temperaturas)
            {
                Console.WriteLine($"{temp:F2}");
            }
        }

        // Funcion para eliminar una temperatura de la lista
        public static void EliminarTemperatura(List<double> temperaturas)
        {
            Console.WriteLine("Indica la posicion de la temperatura que deseas eliminar (empieza desde 0):");
            int indice = int.Parse(Console.ReadLine());

            if (indice >= 0 && indice < temperaturas.Count)
            {
                temperaturas.RemoveAt(indice);
                Console.WriteLine("Temperatura eliminada");
            }
            else
            {
                Console.WriteLine("Invalido");
            }
        }
    }
}