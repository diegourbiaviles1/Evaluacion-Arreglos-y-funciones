﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio__3._2_Evaluación
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<double> temperaturasCelsius = new List<double>();
            List<double> temperaturasFahrenheit = new List<double>();
            List<double> temperaturasKelvin = new List<double>();

            bool continuar = true;

            while (continuar)
            {
                Console.WriteLine("Indica la temperatura en grados Celsius:");
                double temperaturaCelsius = double.Parse(Console.ReadLine());
                temperaturasCelsius.Add(temperaturaCelsius);

                // Convertir a Fahrenheit y Kelvin
                double fahrenheit = ConversionTemperaturas.ConvertirAFahrenheit(temperaturaCelsius);
                double kelvin = ConversionTemperaturas.ConvertirAKelvin(temperaturaCelsius);

                temperaturasFahrenheit.Add(fahrenheit);
                temperaturasKelvin.Add(kelvin);

                // Mostrar las listas de temperaturas convertidas
                ConversionTemperaturas.ImprimirListaTemperaturas(temperaturasFahrenheit, "Fahrenheit");
                ConversionTemperaturas.ImprimirListaTemperaturas(temperaturasKelvin, "Kelvin");

                // Preguntar si desea eliminar una temperatura
                Console.WriteLine("¿Deseas eliminar una temperatura de las listas? (s/n)");
                string respuestaEliminar = Console.ReadLine().ToLower();

                if (respuestaEliminar == "s")
                {
                    Console.WriteLine("¿De cual lista deseas eliminar? (1. Fahrenheit, 2. Kelvin)");
                    int opcionLista = int.Parse(Console.ReadLine());

                    if (opcionLista == 1)
                    {
                        ConversionTemperaturas.EliminarTemperatura(temperaturasFahrenheit);
                    }
                    else if (opcionLista == 2)
                    {
                        ConversionTemperaturas.EliminarTemperatura(temperaturasKelvin);
                    }
                    else
                    {
                        Console.WriteLine("Opcion no valida.");
                    }
                }

                // Preguntar si desea continuar
                Console.WriteLine("¿Deseas ingresar otra temperatura? (s/n)");
                string respuesta = Console.ReadLine().ToLower();
                if (respuesta != "s")
                {
                    continuar = false;
                }
            }
        }
    }
}