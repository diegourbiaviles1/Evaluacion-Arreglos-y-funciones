﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio__3__guia_didactica
{
    public static class ADestudiante
    {
        // Estructura para representar a un estudiante
        public struct Estudiante
        {
            public string Nombre;
            public List<double> Calificaciones;
        }

        // Función para agregar estudiantes
        public static void AgregarEstudiante(List<Estudiante> estudiantes, string nombre, List<double> calificaciones)
        {
            Estudiante nuevoEstudiante = new Estudiante
            {
                Nombre = nombre,
                Calificaciones = calificaciones
            };
            estudiantes.Add(nuevoEstudiante);
        }

        // Función para calcular el promedio de un estudiante
        public static double CalcularPromedio(List<double> calificaciones)
        {
            return calificaciones.Average();
        }

        // Función para determinar el estudiante con el promedio más alto y más bajo
        public static void DeterminarAltoBajoEstudiante(List<Estudiante> estudiantes)
        {
            Estudiante estudianteMayorPromedio = estudiantes[0];
            Estudiante estudianteMenorPromedio = estudiantes[0];

            foreach (var estudiante in estudiantes)
            {
                double promedio = CalcularPromedio(estudiante.Calificaciones);

                if (promedio > CalcularPromedio(estudianteMayorPromedio.Calificaciones))
                {
                    estudianteMayorPromedio = estudiante;
                }

                if (promedio < CalcularPromedio(estudianteMenorPromedio.Calificaciones))
                {
                    estudianteMenorPromedio = estudiante;
                }
            }

            Console.WriteLine($"Estudiante con el promedio más alto: {estudianteMayorPromedio.Nombre} con {CalcularPromedio(estudianteMayorPromedio.Calificaciones)}");
            Console.WriteLine($"Estudiante con el promedio más bajo: {estudianteMenorPromedio.Nombre} con {CalcularPromedio(estudianteMenorPromedio.Calificaciones)}");
        }
    }
}D



