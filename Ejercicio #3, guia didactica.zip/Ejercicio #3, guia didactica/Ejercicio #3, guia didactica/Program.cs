﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio__3__guia_didactica
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<ADestudiante.Estudiante> estudiantes = new List<ADestudiante.Estudiante>();
            bool continuar = true;

            while (continuar)
            {
                Console.Write("Ingresa el nombre del estudiante: ");
                string nombre = Console.ReadLine();

                Console.Write("¿Cuántas calificaciones tiene el estudiante? ");
                int cantidadCalificaciones = int.Parse(Console.ReadLine());

                List<double> calificaciones = new List<double>();

                for (int i = 0; i < cantidadCalificaciones; i++)
                {
                    Console.Write($"Ingresa la calificación {i + 1}: ");
                    double calificacion = double.Parse(Console.ReadLine());
                    calificaciones.Add(calificacion);
                }

                ADestudiante.AgregarEstudiante(estudiantes, nombre, calificaciones);

                Console.Write("¿Deseas agregar otro estudiante? (s/n): ");
                string respuesta = Console.ReadLine().ToLower();
                continuar = respuesta == "s";
            }

            ADestudiante.DeterminarAltoBajoEstudiante(estudiantes);
        }
    }
}
